$(document).ready(function () {
    $('#message-composer').summernote({height: 500});
});